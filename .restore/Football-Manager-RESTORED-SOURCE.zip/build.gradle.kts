plugins {
 id("com.android.application") version "9.2.1" apply false
 kotlin("jvm") version "2.3.10" apply false
 kotlin("plugin.serialization") version "2.3.10" apply false
 id("org.jetbrains.kotlin.plugin.compose") version "2.3.10" apply false
 id("com.google.devtools.ksp") version "2.3.12" apply false
}
